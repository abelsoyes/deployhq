<?php
/**
* 2007-2025 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2025 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Soyrecaptcha extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'soyrecaptcha';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Soy.es';
        $this->need_instance = 1;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Google Recapctha Modular');
        $this->description = $this->l('Módulo que nos permite en que partes de la web queremos cargar el Recaptcha de Google');

        $this->confirmUninstall = $this->l('¿Estas seguro de desinstalar nuestro módulo de recaptcha?');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        Configuration::updateValue('SOYRECAPTCHA_LIVE_MODE', false);

        include(dirname(__FILE__).'/sql/install.php');

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('actionAdminControllerSetMedia') &&
            $this->registerHook('displayHeader');
    }

    public function uninstall()
    {
        Configuration::deleteByName('SOYRECAPTCHA_LIVE_MODE');

        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitSoyrecaptchaModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

   

        return $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    public function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l(' Configuración Recaptcha Google'),
                    'icon' => 'icon-cogs',
                ],
                'tabs' => [
                    'general' => $this->l('Configuración general'),
                    'advanced' => $this->l('Parámetros avanzados'),
                ],
                'description' => $this->l('Necesitas obtener primero las llaves de acceso de Google, puedes seguir este enlace:')
                    . '<br /><a href="https://www.google.com/recaptcha/intro/index.html" target="_blank">https://www.google.com/recaptcha/intro/index.html</a>',
                'input' => [
                    [
                        'type' => 'radio',
                        'label' => $this->l('Recaptcha Version'),
                        'name' => 'CAPTCHA_VERSION',
                        'required' => true,
                        'class' => 't',
                        'values' => [
                            [
                                'id' => 'v3',
                                'value' => 3,
                                'label' => $this->l('V3'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Captcha Google llave pública (Site key)'),
                        'name' => 'CAPTCHA_PUBLIC_KEY',
                        'required' => true,
                        'empty_message' => $this->l('Please fill the captcha public key'),
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Captcha Google llave privada (Secret key)'),
                        'name' => 'CAPTCHA_PRIVATE_KEY',
                        'required' => true,
                        'empty_message' => $this->l('Please fill the captcha private key'),
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Habilitar Captcha para usuarios logueados'),
                        'name' => 'CAPTCHA_ENABLE_LOGGED_CUSTOMERS',
                        'required' => true,
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Define if logged customers need to use captcha or not'),
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Activo'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desactivado'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Habilitar Capctha para formulario contacto'),
                        'name' => 'CAPTCHA_ENABLE_CONTACT',
                        'required' => true,
                        'class' => 't',
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Activo'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desactivado'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Habilitar capctha para registro'),
                        'name' => 'CAPTCHA_ENABLE_ACCOUNT',
                        'required' => true,
                        'class' => 't',
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Activo'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desactivado'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activar captcha para newsletter'),
                        'hint' => $this->l('Only availaibles in certain conditions*'),
                        'name' => 'CAPTCHA_ENABLE_NEWSLETTER',
                        'required' => true,
                        'class' => 't',
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Activo'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desactivado'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'radio',
                        'label' => $this->l('Diseño del capctha'),
                        'name' => 'CAPTCHA_THEME',
                        'required' => true,
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'cdark',
                                'value' => 0,
                                'label' => $this->l('Dark'),
                            ],
                            [
                                'id' => 'clight',
                                'value' => 1,
                                'label' => $this->l('Light'),
                            ],
                        ],
                        'tab' => 'general',
                    ],
                    [
                        'type' => 'switch',
                        'name' => 'CAPTCHA_LOAD_EVERYWHERE',
                        'label' => $this->l('Cargar Capctha para toda la web'),
                        'hint' => $this->l('Let this option disabled by default if you don\'t use a specific contact form'),
                        'desc' => $this->l('Habilita esta opción si utilizas elementor o formlarios que no sean por defecto los de Prestashop.'),
                        'required' => false,
                        'class' => 't',
                        'is_bool' => true,
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Activo'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desactivado'),
                            ],
                        ],
                        'tab' => 'advanced',
                    ]
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right',
                ],
            ],
        ];

      

        //For version under PS 8.x we let the choice to the customer to use the override or the hook
        if (version_compare(_PS_VERSION_, '8.0') < 0) {
            $fields_form['form']['input'][] = [
                'type' => 'switch',
                'name' => 'CAPTCHA_USE_AUTHCONTROLLER_OVERRIDE',
                'label' => $this->l('Use the controller override'),
                'hint' => $this->l('Choose if you want to use the override or the hook to validate customers registration'),
                'desc' => $this->l('If you don\'t know what to do with this value let it on the default one'),
                'required' => false,
                'class' => 't',
                'is_bool' => true,
                'values' => [
                    [
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Enabled'),
                    ],
                    [
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('Disabled'),
                    ],
                ],
                'tab' => 'advanced',
            ];
        }

        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitSoyrecaptchaModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm([$fields_form]);
    }


    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'CAPTCHA_VERSION' => Configuration::get('CAPTCHA_VERSION'),
            'CAPTCHA_PRIVATE_KEY' => Configuration::get('CAPTCHA_PRIVATE_KEY'),
            'CAPTCHA_PUBLIC_KEY' => Configuration::get('CAPTCHA_PUBLIC_KEY'),
            'CAPTCHA_ENABLE_LOGGED_CUSTOMERS' => Configuration::get('CAPTCHA_ENABLE_LOGGED_CUSTOMERS'),
            'CAPTCHA_ENABLE_ACCOUNT' => Configuration::get('CAPTCHA_ENABLE_ACCOUNT'),
            'CAPTCHA_ENABLE_CONTACT' => Configuration::get('CAPTCHA_ENABLE_CONTACT'),
            'CAPTCHA_ENABLE_NEWSLETTER' => Configuration::get('CAPTCHA_ENABLE_NEWSLETTER'),
            'CAPTCHA_THEME' => Configuration::get('CAPTCHA_THEME'),
            'CAPTCHA_LOAD_EVERYWHERE' => Configuration::get('CAPTCHA_LOAD_EVERYWHERE'),
            
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
       

        $captchaVersion = Configuration::get('CAPTCHA_VERSION');
        //Add Content box to contact form page in order to display captcha
        if (Configuration::get('CAPTCHA_LOAD_EVERYWHERE') == 1
        ) {
            $this->context->controller->addJS($this->_path.'views/js/eicaptcha-contact-form-v' . $captchaVersion . '.js');
            return $this->renderHeaderV3();
        }
  
      
        
    }

    public function renderHeaderV3()
    {
       
            $publicKey = Configuration::get('CAPTCHA_PUBLIC_KEY');
            $js = '
            <script src="https://www.google.com/recaptcha/api.js?render=' . $publicKey . '"></script>
            <script>
                grecaptcha.ready(function () {
                    grecaptcha.execute("' . $publicKey . '", {action: "contact"}).then(function (token) {
                        var recaptchaResponse = document.getElementById("captcha-box");
                        recaptchaResponse.value = token;
                        });
                    });
            </script>';

            return $js;
        
    }


    public function hookActionAdminControllerSetMedia()
    {
        /* Place your code here. */
    }

    public function hookActionContactFormSubmitBefore($params)
    {
        if (!Tools::getValue('g-recaptcha-response')) {
            $this->context->controller->errors[] = $this->l('Por favor, completa el captcha.');
            return;
        }

        $recaptchaSecret = Configuration::get('CAPTCHA_PRIVATE_KEY');
        $response = Tools::file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptchaSecret&response=" . Tools::getValue('g-recaptcha-response'));
        $responseKeys = json_decode($response, true);

        if (!$responseKeys["success"]) {
            $this->context->controller->errors[] = $this->l('Error en la validación del captcha.');
        }

        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify'; 
        $recaptcha_secret = Configuration::get('CAPTCHA_PRIVATE_KEY');
        $recaptcha_response = Tools::getValue('g-recaptcha-response'); 
        $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response); 
        $recaptcha = json_decode($recaptcha); 

        if($recaptcha->score >= 0.7){
            $this->context->controller->errors[] = $this->l('Error en la validación del HUMANO.');
        }else{
            $this->context->controller->errors[] = $this->l('Error en la validación del captcha.');
        }
    }




}
